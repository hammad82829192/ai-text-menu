# AI Text Menu
Chat with an AI inside Geometry Dash. Tap the **AI** button on the main menu.

Setup: Geode > AI Text Menu > Settings, then paste your API key.
Works with any OpenAI-compatible endpoint.

By **hammadus**
