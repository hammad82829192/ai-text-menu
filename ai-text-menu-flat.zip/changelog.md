# v1.0.0
- First release: AI text menu on the main menu.
